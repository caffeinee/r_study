## [R로하는 데이터 시각화 :  고객을 설득하는 데이터 시각화 실전 노하우](http://www.hanb.co.kr/ebook/look.html?isbn=9788968486494)

![R로 하는 데이터 시각화](http://image.hanb.co.kr/ebookcover/m_9788968486494.gif)

* 책에 쓰인 데이터  제공을 위한 저장소 


### 다운로드 방법 두 가지 

### Git에 익숙한 사용자 

```
git clone https://github.com/haven-jeon/R_based_visualization.git
```


### Git에 익숙하지 않은 사용자 

화면 우측 하단의 `Download ZIP` 버튼을 눌러 다운받는다. 


### 의문이 생겼을시 

* mail to <madjakarta@gmail.com> 혹은 <http://freesearch.pe.kr>







